/**
 * ExamConnGuard — Verbindungs-Schutz im Test-Player
 * Part of ExtendedTestSettings Plugin
 *
 * Fängt kurze WLAN-Aussetzer ab, bevor der Browser eine Fehlerseite zeigt.
 *
 * Strategie:
 *   - Aktiver Heartbeat (HEAD auf /favicon.ico mit Cache-Bust) erkennt Outages
 *     auch wenn der Browser noch "online" meldet.
 *   - Bei Offline: Vollbild-Overlay (Shadow-DOM, kein CSS-Konflikt mit ILIAS).
 *   - Submit/Klick-Events werden während Offline gequeued.
 *   - Bei Reconnect mit 800ms Stabilitäts-Fenster: Overlay weg + Queue replay.
 *   - fetch() global gewrappt mit Exponential-Backoff (max 6 Versuche).
 *   - beforeunload schützt vor F5/Strg+R während Offline.
 */
(function () {
    'use strict';

    function getCfg() {
        var c = (window.ExamConnGuard && window.ExamConnGuard.config) || {};
        return {
            refId:            c.refId || 0,
            heartbeatUrl:     c.heartbeatUrl || '/favicon.ico',
            heartbeatMs:      c.heartbeatMs || 8000,
            heartbeatTimeout: c.heartbeatTimeout || 4000,
            reconnectGraceMs: c.reconnectGraceMs || 800,
            debug:            !!c.debug
        };
    }

    var cfg = getCfg();

    function log() {
        if (!cfg.debug) {
            return;
        }
        var args = Array.prototype.slice.call(arguments);
        args.unshift('[ExamConnGuard]');
        console.log.apply(console, args);
    }

    // ─── State ───────────────────────────────────────────────────────────────

    var isOnline       = (typeof navigator.onLine === 'boolean') ? navigator.onLine : true;
    var outageStart    = 0;
    var heartbeatTimer = null;
    var graceTimer     = null;
    var pendingAction  = null;
    var overlayHost    = null;
    var overlayShadow  = null;
    var timerInterval  = null;
    var beforeUnloadOn = false;

    // ─── Overlay (Shadow-DOM — entkoppelt von ILIAS-CSS) ─────────────────────

    var OVERLAY_CSS = ''
        + ':host{all:initial;}'
        + '.wrap{position:fixed;inset:0;z-index:2147483647;display:flex;align-items:center;'
        + 'justify-content:center;background:rgba(20,20,30,0.78);backdrop-filter:blur(10px);'
        + '-webkit-backdrop-filter:blur(10px);font-family:-apple-system,BlinkMacSystemFont,'
        + '"Segoe UI",Roboto,Helvetica,Arial,sans-serif;color:#222;}'
        + '.box{background:#fff;border-radius:10px;padding:36px 44px;max-width:480px;width:90%;'
        + 'text-align:center;box-shadow:0 12px 48px rgba(0,0,0,0.45);}'
        + '.icon{font-size:46px;line-height:1;margin-bottom:14px;}'
        + '.title{font-size:22px;font-weight:600;margin:0 0 10px 0;color:#1a1a1a;}'
        + '.msg{margin:6px 0;font-size:15px;line-height:1.5;color:#333;}'
        + '.timer{margin-top:18px;font-variant-numeric:tabular-nums;font-size:15px;color:#666;}'
        + '.spinner{display:inline-block;width:14px;height:14px;border:2px solid #ccc;'
        + 'border-top-color:#2980b9;border-radius:50%;animation:ecg-spin 0.9s linear infinite;'
        + 'margin-right:8px;vertical-align:-2px;}'
        + '@keyframes ecg-spin{to{transform:rotate(360deg);}}';

    function buildOverlay() {
        if (overlayHost) {
            return;
        }
        overlayHost = document.createElement('div');
        overlayHost.id = 'examconnguard-host';
        overlayHost.style.cssText = 'position:fixed;inset:0;z-index:2147483647;';

        overlayShadow = overlayHost.attachShadow ? overlayHost.attachShadow({ mode: 'closed' }) : null;
        var root = overlayShadow || overlayHost;

        var style = document.createElement('style');
        style.textContent = OVERLAY_CSS;
        root.appendChild(style);

        var wrap = document.createElement('div');
        wrap.className = 'wrap';
        wrap.innerHTML = ''
            + '<div class="box">'
            + '<div class="icon">📡</div>'
            + '<h2 class="title">Verbindung unterbrochen</h2>'
            + '<p class="msg">Bitte warten — Ihre Eingaben werden gesichert.</p>'
            + '<p class="msg">Sobald die Verbindung wiederhergestellt ist, '
            + 'geht es automatisch weiter. Bitte <strong>nicht</strong> neu laden.</p>'
            + '<div class="timer"><span class="spinner"></span>'
            + 'Unterbrochen seit <span id="ecg-elapsed">0</span> s</div>'
            + '</div>';
        root.appendChild(wrap);

        document.body.appendChild(overlayHost);
    }

    function showOverlay() {
        buildOverlay();
        outageStart = Date.now();
        updateElapsed();
        if (timerInterval) {
            clearInterval(timerInterval);
        }
        timerInterval = setInterval(updateElapsed, 1000);
    }

    function hideOverlay() {
        if (timerInterval) {
            clearInterval(timerInterval);
            timerInterval = null;
        }
        if (overlayHost && overlayHost.parentNode) {
            overlayHost.parentNode.removeChild(overlayHost);
        }
        overlayHost = null;
        overlayShadow = null;
    }

    function updateElapsed() {
        if (!overlayHost) {
            return;
        }
        var root = overlayShadow || overlayHost;
        var el = root.getElementById ? root.getElementById('ecg-elapsed') : null;
        if (!el && root.querySelector) {
            el = root.querySelector('#ecg-elapsed');
        }
        if (el) {
            el.textContent = String(Math.floor((Date.now() - outageStart) / 1000));
        }
    }

    // ─── Heartbeat ───────────────────────────────────────────────────────────

    function probe() {
        return new Promise(function (resolve) {
            var ctrl = (typeof AbortController !== 'undefined') ? new AbortController() : null;
            var timeoutId = setTimeout(function () {
                if (ctrl) { ctrl.abort(); }
                resolve(false);
            }, cfg.heartbeatTimeout);

            var url = cfg.heartbeatUrl + (cfg.heartbeatUrl.indexOf('?') >= 0 ? '&' : '?')
                + '_ecg=' + Date.now();

            var opts = { method: 'HEAD', cache: 'no-store', credentials: 'same-origin' };
            if (ctrl) { opts.signal = ctrl.signal; }

            // _origFetch verwenden, sonst recursion durch unseren Wrapper.
            (window.ExamConnGuard._origFetch || window.fetch).call(window, url, opts)
                .then(function (res) {
                    clearTimeout(timeoutId);
                    resolve(res && res.ok);
                })
                .catch(function () {
                    clearTimeout(timeoutId);
                    resolve(false);
                });
        });
    }

    function startHeartbeat() {
        if (heartbeatTimer) {
            return;
        }
        heartbeatTimer = setInterval(function () {
            probe().then(function (ok) {
                if (ok && !isOnline) {
                    handleOnline('heartbeat');
                } else if (!ok && isOnline) {
                    handleOffline('heartbeat');
                }
            });
        }, cfg.heartbeatMs);
    }

    // ─── Online/Offline-Handling ─────────────────────────────────────────────

    function handleOffline(source) {
        if (!isOnline) {
            return;
        }
        log('offline (' + source + ')');
        isOnline = false;
        if (graceTimer) {
            clearTimeout(graceTimer);
            graceTimer = null;
        }
        showOverlay();
        enableBeforeUnload();
    }

    function handleOnline(source) {
        if (isOnline) {
            return;
        }
        log('online-candidate (' + source + ')');
        // Stabilitäts-Fenster: warten ob die Verbindung kurz wieder weg flackert.
        if (graceTimer) {
            clearTimeout(graceTimer);
        }
        graceTimer = setTimeout(function () {
            graceTimer = null;
            isOnline = true;
            log('online (confirmed)');
            hideOverlay();
            disableBeforeUnload();
            replayQueued();
        }, cfg.reconnectGraceMs);
    }

    // ─── beforeunload-Schutz ─────────────────────────────────────────────────

    function beforeUnloadHandler(e) {
        e.preventDefault();
        e.returnValue = 'Verbindung ist unterbrochen. Bitte warten — die Seite läuft weiter, sobald die Verbindung wieder da ist.';
        return e.returnValue;
    }

    function enableBeforeUnload() {
        if (beforeUnloadOn) {
            return;
        }
        window.addEventListener('beforeunload', beforeUnloadHandler);
        beforeUnloadOn = true;
    }

    function disableBeforeUnload() {
        if (!beforeUnloadOn) {
            return;
        }
        window.removeEventListener('beforeunload', beforeUnloadHandler);
        beforeUnloadOn = false;
    }

    // ─── Submit/Click-Interceptor ────────────────────────────────────────────

    function isSubmitTarget(el) {
        if (!el) { return false; }
        var tag = (el.tagName || '').toLowerCase();
        if (tag === 'button' || tag === 'input') {
            var type = (el.getAttribute('type') || '').toLowerCase();
            if (type === 'submit' || type === 'image') { return true; }
            if (tag === 'button' && (!type || type === '')) { return true; }
        }
        if (tag === 'a' && el.getAttribute('href')) {
            return true;
        }
        return false;
    }

    function findSubmitAncestor(el) {
        var node = el;
        while (node && node !== document.body) {
            if (isSubmitTarget(node)) { return node; }
            node = node.parentNode;
        }
        return null;
    }

    function queueAction(action) {
        // Nur eine pending action — neuere überschreibt ältere.
        // Studi klickt im Zweifel mehrmals "Weiter"; das letzte Klicken zählt.
        pendingAction = action;
        log('queued action', action);
    }

    function replayQueued() {
        if (!pendingAction) {
            return;
        }
        var action = pendingAction;
        pendingAction = null;
        log('replaying', action);

        // Nach dem Reconnect: kurzer Defer, damit eventuelle State-Updates
        // (z. B. eingegebener Text in Inputs) sicher persistiert sind.
        setTimeout(function () {
            try {
                if (action.type === 'submit' && action.form && action.form.isConnected !== false) {
                    if (typeof action.form.requestSubmit === 'function' && action.submitter) {
                        action.form.requestSubmit(action.submitter);
                    } else {
                        action.form.submit();
                    }
                } else if (action.type === 'click' && action.element && action.element.isConnected !== false) {
                    action.element.click();
                } else if (action.type === 'navigate' && action.href) {
                    window.location.href = action.href;
                }
            } catch (err) {
                log('replay error', err);
            }
        }, 50);
    }

    function onSubmitCapture(e) {
        if (isOnline) {
            return;
        }
        e.preventDefault();
        e.stopPropagation();
        queueAction({
            type:      'submit',
            form:      e.target,
            submitter: e.submitter || null
        });
    }

    function onClickCapture(e) {
        if (isOnline) {
            return;
        }
        var target = findSubmitAncestor(e.target);
        if (!target) {
            return;
        }
        e.preventDefault();
        e.stopPropagation();

        var tag = (target.tagName || '').toLowerCase();
        if (tag === 'a') {
            queueAction({ type: 'navigate', href: target.href });
        } else {
            queueAction({ type: 'click', element: target });
        }
    }

    // ─── fetch()-Wrapper mit Exponential Backoff ─────────────────────────────

    var MAX_RETRIES = 6;

    function isRetriable(err) {
        // TypeError ist Chrome's Marker für "fetch konnte gar nicht senden"
        // (DNS, kein Netz). 5xx-Status werden separat behandelt.
        return (err && err.name === 'TypeError') || (err && err.name === 'AbortError');
    }

    function wrapFetch() {
        if (!window.fetch || window.ExamConnGuard._fetchWrapped) {
            return;
        }
        var origFetch = window.fetch.bind(window);
        window.ExamConnGuard._origFetch = origFetch;
        window.ExamConnGuard._fetchWrapped = true;

        window.fetch = function (input, init) {
            var attempt = 0;

            function tryOnce() {
                return origFetch(input, init).then(function (res) {
                    if (res.status >= 500 && res.status < 600 && attempt < MAX_RETRIES) {
                        return backoff();
                    }
                    return res;
                }).catch(function (err) {
                    if (isRetriable(err) && attempt < MAX_RETRIES) {
                        // Wenn fetch hart fehlschlägt: wahrscheinlich Outage.
                        if (isOnline) {
                            handleOffline('fetch-error');
                        }
                        return backoff();
                    }
                    throw err;
                });
            }

            function backoff() {
                attempt++;
                var delay = Math.min(30000, 500 * Math.pow(2, attempt - 1));
                log('fetch retry', attempt, 'in', delay, 'ms');
                return new Promise(function (resolve) {
                    setTimeout(function () { resolve(tryOnce()); }, delay);
                });
            }

            return tryOnce();
        };
    }

    // ─── Init ────────────────────────────────────────────────────────────────

    window.ExamConnGuard = window.ExamConnGuard || {};
    window.ExamConnGuard.config = window.ExamConnGuard.config || {};

    wrapFetch();

    window.addEventListener('offline', function () { handleOffline('event'); });
    window.addEventListener('online',  function () { handleOnline('event'); });

    // Capture-Phase: greift VOR ILIAS-Handlern, sodass wir sauber unterbinden können.
    document.addEventListener('submit', onSubmitCapture, true);
    document.addEventListener('click',  onClickCapture,  true);

    startHeartbeat();

    log('initialized', cfg);
    console.log('[ExamConnGuard] Connection guard activated');
})();
