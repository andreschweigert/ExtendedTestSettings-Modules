<?php
/**
 * ExamConnGuard Handler - Verbindungs-Schutz im Test-Player
 * Part of ExtendedTestSettings Plugin
 */

class ilExamConnGuardHandler implements ilExamModuleInterface
{
    private string $plugin_path;

    // Heartbeat-Defaults — können später per Plugin-Setting überschrieben werden.
    private const HEARTBEAT_URL          = '/favicon.ico';
    private const HEARTBEAT_INTERVAL_MS  = 8000;
    private const HEARTBEAT_TIMEOUT_MS   = 4000;
    private const RECONNECT_GRACE_MS     = 800;

    public function __construct(string $plugin_path)
    {
        $this->plugin_path = $plugin_path;
    }

    /**
     * Prüft ob ExamConnGuard für den Test aktiviert ist.
     */
    public function isEnabled(int $ref_id): bool
    {
        global $DIC;
        $db = $DIC->database();

        try {
            $test_id = ilObject::_lookupObjectId($ref_id);

            if ($test_id <= 0) {
                return false;
            }

            $result = $db->queryF(
                'SELECT enabled FROM examconnguard_settings WHERE test_id = %s',
                ['integer'],
                [$test_id]
            );

            if ($row = $db->fetchAssoc($result)) {
                return (bool) $row['enabled'];
            }
        } catch (Exception $e) {
            error_log('[ExamConnGuard] Fehler beim Prüfen der Aktivierung: ' . $e->getMessage());
        }

        return false;
    }

    /**
     * Prüft ob aktueller Kontext ein Testplayer ist.
     */
    public function isTestPlayerContext(): bool
    {
        $cmd_class = strtolower($_GET['cmdClass'] ?? '');

        $player_classes = [
            'iltestplayer',
            'iltestplayergui',
            'iltestplayercommandsgui',
            'iltestoutputgui',
        ];

        foreach ($player_classes as $cls) {
            if (str_contains($cmd_class, $cls)) {
                return true;
            }
        }

        $uri = $_SERVER['REQUEST_URI'] ?? '';
        return str_contains($uri, 'cmd=startPlayer')
            || str_contains($uri, 'cmd=resumePlayer')
            || str_contains($uri, 'cmdClass=ilTestPlayer');
    }

    /**
     * Injiziert Assets (CSS, JS, Config) in den Test-Player.
     */
    public function injectAssets(ilGlobalTemplateInterface $tpl, int $ref_id): void
    {
        if (!$this->isEnabled($ref_id) || !$this->isTestPlayerContext()) {
            return;
        }

        $module_path = $this->plugin_path . '/modules/examconnguard';

        $config = [
            'refId'            => $ref_id,
            'heartbeatUrl'     => self::HEARTBEAT_URL,
            'heartbeatMs'      => self::HEARTBEAT_INTERVAL_MS,
            'heartbeatTimeout' => self::HEARTBEAT_TIMEOUT_MS,
            'reconnectGraceMs' => self::RECONNECT_GRACE_MS,
            'debug'            => false,
        ];

        $config_json = json_encode($config);

        // Config MUSS vor dem JS verfügbar sein — examconnguard.js liest beim
        // Laden direkt window.ExamConnGuard.config.
        $tpl->addOnLoadCode("
            window.ExamConnGuard = window.ExamConnGuard || {};
            window.ExamConnGuard.config = {$config_json};
        ");

        $tpl->addCss($module_path . '/css/examconnguard.css');
        $tpl->addJavaScript($module_path . '/js/examconnguard.js');
    }

    /**
     * Speichert die Modul-Einstellungen für diesen Test.
     */
    public function saveSettings(int $ref_id, array $post_data): bool
    {
        global $DIC;
        $db = $DIC->database();

        try {
            $obj_id  = ilObject::_lookupObjectId($ref_id);
            $enabled = isset($post_data['examconnguard_enabled']) ? 1 : 0;

            $db->replace(
                'examconnguard_settings',
                ['test_id' => ['integer', $obj_id]],
                [
                    'enabled'    => ['integer',   $enabled],
                    'updated_at' => ['timestamp', date('Y-m-d H:i:s')],
                ]
            );

            return true;
        } catch (Exception $e) {
            error_log('[ExamConnGuard] Fehler beim Speichern: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Gibt ILIAS-Formular-Elemente für den "Erweiterte Test-Einstellungen"-Tab zurück.
     */
    public function getFormItems(int $ref_id): array
    {
        $cb = new ilCheckboxInputGUI('Verbindungs-Schutz aktivieren', 'examconnguard_enabled');
        $cb->setChecked($this->isEnabled($ref_id));
        $cb->setInfo('Fängt kurze WLAN-Aussetzer im Test-Player ab. Zeigt ein Warte-Overlay statt der Chrome-Fehlerseite, queued Submits und Klicks während der Unterbrechung und holt sie nach dem Reconnect automatisch nach. Empfohlen für Hörsaal-WLAN und Chromebooks.');

        return [$cb];
    }

    /**
     * Gibt Plugin-Info zurück.
     */
    public function getInfo(): array
    {
        return [
            'name'        => 'ExamConnGuard',
            'title'       => 'Verbindungs-Schutz',
            'icon'        => '📡',
            'description' => 'Fängt kurze Verbindungs-Aussetzer im Test-Player ab und verhindert Browser-Fehlerseiten',
            'version'     => '1.0.0',
            'features'    => [
                'Aktiver Heartbeat alle 8s gegen /favicon.ico',
                'Vollbild-Overlay mit Outage-Timer bei Offline-Status',
                'Queued Submits & Submit-Klicks während Outage',
                'Auto-Replay nach Reconnect (mit 800ms Stabilitäts-Fenster)',
                'fetch()-Wrapper mit Exponential-Backoff (max 6 Versuche) für Autosaves',
                'beforeunload-Schutz gegen versehentliches F5/Strg+R während Offline',
            ],
        ];
    }
}
