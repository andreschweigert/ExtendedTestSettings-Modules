<?php

/**
 * GUI für Fragengruppierung
 * Erlaubt das Definieren von Fragegruppen und zeigt Ergebnisse je Gruppe.
 * Schreibt ausschließlich in Plugin-eigene Tabellen (examgrouping_*).
 * ILIAS-Kerntabellen werden nur gelesen.
 *
 * @ilCtrl_isCalledBy ilExamGroupingGUI: ilUIPluginRouterGUI
 */
class ilExamGroupingGUI
{
    private ilCtrl $ctrl;
    private ilGlobalTemplateInterface $tpl;
    private ilDBInterface $db;
    private ilModuleLanguage $lng;

    public function __construct()
    {
        global $DIC;
        $this->ctrl = $DIC->ctrl();
        $this->tpl  = $DIC->ui()->mainTemplate();
        $this->db   = $DIC->database();

        // Modul-eigene Sprachdatei (lang/ilias_<lang>.lang in diesem Modulverzeichnis)
        require_once __DIR__ . '/../../classes/Module/ilModuleLanguage.php';
        $this->lng  = new ilModuleLanguage(__DIR__);
    }

    private function txt(string $key): string
    {
        return $this->lng->txt($key);
    }

    public function executeCommand(): void
    {
        $post_cmd = $_POST['cmd'] ?? null;
        $cmd = is_array($post_cmd) ? (string) array_key_first($post_cmd) : ($_GET['cmd'] ?? 'show');
        $this->performCommand($cmd);
    }

    private function proxyLink(string $cmd, array $params = []): string
    {
        $this->ctrl->setParameterByClass('ilExtendedTestSettingsModuleProxyGUI', 'module_id', 'examgrouping');
        foreach ($params as $k => $v) {
            $this->ctrl->setParameterByClass('ilExtendedTestSettingsModuleProxyGUI', $k, (string) $v);
        }
        return $this->ctrl->getLinkTargetByClass(
            ['ilUIPluginRouterGUI', 'ilExtendedTestSettingsModuleProxyGUI'],
            $cmd
        );
    }

    private function proxyFormAction(string $cmd, array $params = []): string
    {
        $this->ctrl->setParameterByClass('ilExtendedTestSettingsModuleProxyGUI', 'module_id', 'examgrouping');
        foreach ($params as $k => $v) {
            $this->ctrl->setParameterByClass('ilExtendedTestSettingsModuleProxyGUI', $k, (string) $v);
        }
        return $this->ctrl->getFormActionByClass(
            ['ilUIPluginRouterGUI', 'ilExtendedTestSettingsModuleProxyGUI'],
            $cmd
        );
    }

    private function proxyRedirect(string $cmd, array $params = []): void
    {
        $this->ctrl->setParameterByClass('ilExtendedTestSettingsModuleProxyGUI', 'module_id', 'examgrouping');
        foreach ($params as $k => $v) {
            $this->ctrl->setParameterByClass('ilExtendedTestSettingsModuleProxyGUI', $k, (string) $v);
        }
        $this->ctrl->redirectByClass(
            ['ilUIPluginRouterGUI', 'ilExtendedTestSettingsModuleProxyGUI'],
            $cmd
        );
    }

    private function getDeleteToken(): string
    {
        $token = ilSession::get('examgrouping_delete_token');
        if (!is_string($token) || $token === '') {
            $token = bin2hex(random_bytes(16));
            ilSession::set('examgrouping_delete_token', $token);
        }
        return $token;
    }

    private function renderDeleteForm(int $ref_id, int $group_id, string $name): string
    {
        $action = htmlspecialchars($this->proxyFormAction('deleteGroup', ['ref_id' => $ref_id]), ENT_QUOTES, 'UTF-8');
        $token = htmlspecialchars($this->getDeleteToken(), ENT_QUOTES, 'UTF-8');
        $message = json_encode(
            sprintf($this->txt('confirm_delete'), $name),
            JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_THROW_ON_ERROR
        );
        $confirm = htmlspecialchars('return confirm(' . $message . ');', ENT_QUOTES, 'UTF-8');

        return '<form method="post" action="' . $action . '" style="display:inline" onsubmit="' . $confirm . '">'
            . '<input type="hidden" name="group_id" value="' . $group_id . '">'
            . '<input type="hidden" name="examgrouping_delete_token" value="' . $token . '">'
            . '<button type="submit" name="cmd[deleteGroup]" class="btn btn-sm btn-danger">' . htmlspecialchars($this->txt('btn_delete'), ENT_QUOTES, 'UTF-8') . '</button>'
            . '</form>';
    }

    public function performCommand(string $cmd): void
    {
        global $DIC, $rbacsystem;

        $ref_id = (int) ($_GET['ref_id'] ?? $_POST['ref_id'] ?? 0);

        if (!$DIC->user()->getId() || $DIC->user()->isAnonymous()) {
            $DIC->ctrl()->redirectToURL('./login.php');
            return;
        }

        if ($ref_id <= 0) {
            $this->tpl->setOnScreenMessage('failure', $this->txt('no_valid_test'));
            $this->tpl->printToStdout();
            return;
        }

        $is_admin = $rbacsystem->checkAccess('write', SYSTEM_FOLDER_ID);
        $has_write = $rbacsystem->checkAccess('write', $ref_id);

        if (!$is_admin && !$has_write) {
            $this->tpl->setOnScreenMessage('failure', $this->txt('no_permission'));
            $DIC->ctrl()->redirectToURL("ilias.php?ref_id={$ref_id}&baseClass=ilRepositoryGUI");
            return;
        }

        switch ($cmd) {
            case 'addGroup':
                $this->addGroup($ref_id);
                break;
            case 'saveGroup':
                $this->saveGroup($ref_id);
                break;
            case 'deleteGroup':
                $this->deleteGroup($ref_id);
                break;
            case 'editGroup':
                $this->editGroup($ref_id);
                break;
            case 'saveGroupQuestions':
                $this->saveGroupQuestions($ref_id);
                break;
            case 'editGroupSettings':
                $this->editGroupSettings($ref_id);
                break;
            case 'saveGroupSettings':
                $this->saveGroupSettings($ref_id);
                break;
            case 'exportResults':
                $this->exportResults($ref_id);
                return; // exit() im Export, kein printToStdout nötig
            default:
                $this->show($ref_id);
                break;
        }

        $this->tpl->printToStdout();
    }

    // =========================================================================
    // Navigation
    // =========================================================================

    private function setupNavigation(int $ref_id): void
    {
        global $DIC, $ilTabs, $ilLocator;

        try {
            $test_title = ilObject::_lookupTitle(ilObject::_lookupObjectId($ref_id));

            $tabs = $ilTabs ?? ($DIC->offsetExists('ilTabs') ? $DIC['ilTabs'] : null);
            if ($tabs) {
                $back_url = "ilias.php?ref_id={$ref_id}&baseClass=ilRepositoryGUI";
                $tabs->setBackTarget('← ' . $test_title, $back_url);

                $tabs->addTab(
                    'exam_grouping',
                    $this->txt('title'),
                    $this->proxyLink('show', ['ref_id' => $ref_id])
                );
                $tabs->activateTab('exam_grouping');
            }

            $this->tpl->setTitle($this->txt('title'));
            $this->tpl->setDescription($this->txt('nav_desc'));
        } catch (Exception $e) {
            // Navigation-Setup ist nicht kritisch
        }
    }

    // =========================================================================
    // Hauptansicht
    // =========================================================================

    private function show(int $ref_id): void
    {
        $obj_id = ilObject::_lookupObjectId($ref_id);

        $this->setupNavigation($ref_id);

        if (ilObject::_lookupType($obj_id) !== 'tst') {
            $this->tpl->setOnScreenMessage('failure', $this->txt('not_a_test'));
            return;
        }

        $groups = $this->getGroupsForTest($obj_id);

        if ($this->isRandomTest($obj_id)) {
            $pools = $this->getTestPools($obj_id);
            if (empty($pools)) {
                $this->tpl->setOnScreenMessage('info', $this->txt('no_pools'));
                $this->tpl->setContent('<p>' . $this->txt('no_pools_hint') . '</p>');
                return;
            }
            $html  = $this->buildPoolGroupsSection($ref_id, $obj_id, $groups, $pools);
            $html .= $this->buildRandomResultsSection($ref_id, $obj_id, $groups, $pools);
            $this->tpl->setContent($html);
            return;
        }

        $questions = $this->getTestQuestions($obj_id);

        if (empty($questions)) {
            $this->tpl->setOnScreenMessage('info', $this->txt('no_questions'));
        }

        $html  = $this->buildGroupsSection($ref_id, $obj_id, $groups, $questions);
        $html .= $this->buildResultsSection($ref_id, $obj_id, $groups, $questions);

        $this->tpl->setContent($html);
    }

    // =========================================================================
    // Gruppen-Übersicht
    // =========================================================================

    private function buildGroupsSection(int $ref_id, int $obj_id, array $groups, array $questions): string
    {
        $add_link = $this->proxyLink('addGroup', ['ref_id' => $ref_id]);

        $html  = '<div style="margin-bottom:2rem;">';
        $html .= '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1rem;">';
        $html .= '<h3 style="margin:0;">' . $this->txt('groups_heading') . '</h3>';
        $html .= '<a href="' . htmlspecialchars($add_link) . '" class="btn btn-primary">' . $this->txt('btn_new_group') . '</a>';
        $html .= '</div>';

        if (empty($groups)) {
            $html .= '<p class="text-muted">' . $this->txt('no_groups_hint') . '</p>';
        } else {
            $html .= '<table class="table table-striped" style="width:100%;">';
            $html .= '<thead><tr>'
                   . '<th>' . $this->txt('th_group') . '</th>'
                   . '<th>' . $this->txt('th_questions') . '</th>'
                   . '<th>' . $this->txt('th_max_points') . '</th>'
                   . '<th>' . $this->txt('th_threshold') . '</th>'
                   . '<th>' . $this->txt('th_actions') . '</th>'
                   . '</tr></thead><tbody>';

            foreach ($groups as $group) {
                $group_qids = $this->getGroupQuestions($group['id']);
                $max_points = 0.0;
                $q_labels   = [];

                foreach ($group_qids as $qid) {
                    if (isset($questions[$qid])) {
                        $q_labels[]  = 'F' . $questions[$qid]['sequence'] . ': '
                                     . htmlspecialchars($questions[$qid]['title']);
                        $max_points += (float) $questions[$qid]['points'];
                    }
                }

                $edit_link     = $this->proxyLink('editGroup',         ['ref_id' => $ref_id, 'group_id' => $group['id']]);
                $settings_link = $this->proxyLink('editGroupSettings', ['ref_id' => $ref_id, 'group_id' => $group['id']]);

                $q_display = empty($q_labels)
                    ? '<em style="color:#999;">' . $this->txt('no_questions_assigned') . '</em>'
                    : implode('<br>', $q_labels);

                // Schwellenwert anzeigen
                $ttype = $group['threshold_type']  ?? 'percent';
                $tval  = $group['threshold_value'] ?? 50.0;
                if ($ttype === 'points') {
                    $threshold_display = number_format((float) $tval, 2) . ' ' . $this->txt('unit_pts');
                } else {
                    $threshold_display = number_format((float) $tval, 0) . '%';
                }

                $html .= '<tr>';
                $html .= '<td><strong>' . htmlspecialchars($group['name']) . '</strong></td>';
                $html .= '<td>' . $q_display . '</td>';
                $html .= '<td>' . number_format($max_points, 2) . ' ' . $this->txt('unit_pts') . '</td>';
                $html .= '<td>' . htmlspecialchars($threshold_display) . '</td>';
                $html .= '<td style="white-space:nowrap;">';
                $html .= '<a href="' . htmlspecialchars($settings_link) . '" class="btn btn-sm btn-default">' . $this->txt('btn_settings') . '</a> ';
                $html .= '<a href="' . htmlspecialchars($edit_link) . '" class="btn btn-sm btn-default">' . $this->txt('btn_questions') . '</a> ';
                $html .= $this->renderDeleteForm($ref_id, (int) $group['id'], $group['name']);
                $html .= '</td>';
                $html .= '</tr>';
            }

            $html .= '</tbody></table>';
        }

        $html .= '</div>';
        return $html;
    }

    // =========================================================================
    // Ergebnisse-Ansicht
    // =========================================================================

    private function buildResultsSection(int $ref_id, int $obj_id, array $groups, array $questions): string
    {
        if (empty($groups)) {
            return '';
        }

        // Nur Gruppen mit zugeordneten Fragen berücksichtigen
        $active_groups = [];
        foreach ($groups as $group) {
            $qids = $this->getGroupQuestions($group['id']);
            if (!empty($qids)) {
                $active_groups[] = ['group' => $group, 'qids' => $qids];
            }
        }

        $html  = '<hr>';
        $html .= '<h3>' . $this->txt('results_heading') . '</h3>';

        if (empty($active_groups)) {
            $html .= '<p class="text-muted">' . $this->txt('assign_questions_hint') . '</p>';
            return $html;
        }

        $passes = $this->getSubmittedPasses($obj_id);

        if (empty($passes)) {
            $html .= '<p class="text-muted">' . $this->txt('no_passes') . '</p>';
            return $html;
        }

        // Alle qids die irgendeiner Gruppe zugeordnet sind
        $all_grouped_qids = [];
        foreach ($active_groups as $ag) {
            foreach ($ag['qids'] as $qid) {
                $all_grouped_qids[$qid] = true;
            }
        }

        // Nicht zugeordnete Fragen (existieren im Test, aber in keiner Gruppe)
        $ungrouped_qids = [];
        $ungrouped_max  = 0.0;
        foreach ($questions as $qid => $q) {
            if (!isset($all_grouped_qids[$qid])) {
                $ungrouped_qids[] = $qid;
                $ungrouped_max   += (float) $q['points'];
            }
        }
        $has_ungrouped = !empty($ungrouped_qids);

        // Export-Button
        $export_link = $this->proxyLink('exportResults', ['ref_id' => $ref_id]);
        $html .= '<div style="text-align:right;margin-bottom:0.5rem;">'
               . '<a href="' . htmlspecialchars($export_link) . '" class="btn btn-default btn-sm">&#11015; ' . $this->txt('btn_export_csv') . '</a>'
               . '</div>';

        // Tabellenkopf
        $html .= '<div style="overflow-x:auto;">';
        $html .= '<table class="table table-sm table-bordered">';
        $html .= '<thead><tr>';
        $html .= '<th>' . $this->txt('th_participant') . '</th>';
        $html .= '<th style="white-space:nowrap;">' . $this->txt('th_pass') . '</th>';

        // Max-Punkte je aktiver Gruppe vorberechnen
        $group_max = [];
        foreach ($active_groups as $ag) {
            $max_pts = 0.0;
            foreach ($ag['qids'] as $qid) {
                if (isset($questions[$qid])) {
                    $max_pts += (float) $questions[$qid]['points'];
                }
            }
            $group_max[$ag['group']['id']] = $max_pts;

            $ttype = $ag['group']['threshold_type']  ?? 'percent';
            $tval  = (float) ($ag['group']['threshold_value'] ?? 50);
            $threshold_label = $ttype === 'points'
                ? $this->txt('lbl_from') . ' ' . number_format($tval, 2) . ' ' . $this->txt('unit_pts')
                : $this->txt('lbl_from') . ' ' . number_format($tval, 0) . '%';

            $html .= '<th style="white-space:nowrap;">'
                   . htmlspecialchars($ag['group']['name'])
                   . '<br><small style="font-weight:normal;color:#666;">' . $this->txt('lbl_max') . ' '
                   . number_format($max_pts, 2) . ' ' . $this->txt('unit_pts') . '</small>'
                   . '<br><small style="color:#555;">✓ ' . $threshold_label . '</small>'
                   . '</th>';
        }

        // Spalte für nicht zugeordnete Fragen (falls vorhanden)
        if ($has_ungrouped) {
            $html .= '<th style="white-space:nowrap;color:#856404;background:#fff3cd;">'
                   . $this->txt('ungrouped')
                   . '<br><small style="font-weight:normal;">' . $this->txt('lbl_max') . ' ' . number_format($ungrouped_max, 2) . ' ' . $this->txt('unit_pts') . '</small>'
                   . '<br><small>' . count($ungrouped_qids) . ' ' . $this->txt('unit_questions') . '</small>'
                   . '</th>';
        }

        $html .= '<th>' . $this->txt('th_total_all') . '</th>';
        $html .= '</tr></thead><tbody>';

        // Maximalpunkte des Tests: jede Frage einmal, unabhängig von Gruppen
        $test_total_max = 0.0;
        foreach ($questions as $q) {
            $test_total_max += (float) $q['points'];
        }

        // Passes nach Teilnehmer (active_id) gruppieren, Reihenfolge beibehalten
        $by_participant = [];
        foreach ($passes as $pass) {
            $aid = $pass['active_id'];
            if (!isset($by_participant[$aid])) {
                $by_participant[$aid] = [
                    'firstname' => $pass['firstname'],
                    'lastname'  => $pass['lastname'],
                    'login'     => $pass['login'],
                    'passes'    => [],
                ];
            }
            $by_participant[$aid]['passes'][] = $pass;
        }

        // Akkumulatoren für Ø-Zeile — über letzte Passes je Teilnehmer
        $summary_reached       = array_fill_keys(array_column(array_column($active_groups, 'group'), 'id'), 0.0);
        $summary_ungrouped     = 0.0;
        $summary_total_reached = 0.0;
        $participant_count     = count($by_participant);

        foreach ($by_participant as $aid => $participant) {
            $participant_passes = $participant['passes']; // aufsteigend nach pass-Nr
            $pass_count_local   = count($participant_passes);
            $name  = trim(($participant['firstname'] ?? '') . ' ' . ($participant['lastname'] ?? ''));
            $login = $participant['login'] ?? $this->txt('anon');

            // Vorab Gesamtpunkte je Pass berechnen (für Trendpfeil)
            $totals_per_pass = [];
            foreach ($participant_passes as $p) {
                $qr = $this->getQuestionResults($p['active_id'], $p['pass']);
                $t  = 0.0;
                foreach ($questions as $qid => $q) {
                    $t += (float) ($qr[$qid] ?? 0.0);
                }
                $totals_per_pass[$p['pass']] = $t;
            }

            foreach ($participant_passes as $idx => $pass) {
                $q_results  = $this->getQuestionResults($pass['active_id'], $pass['pass']);
                $pass_nr    = $pass['pass'] + 1; // ILIAS zählt ab 0
                $is_first   = ($idx === 0);
                $is_last    = ($idx === $pass_count_local - 1);

                // Zeilenhintergrund: erster Durchlauf neutral, weitere leicht eingerückt
                $row_bg     = $is_first ? '' : 'background:#fafafa;';
                $html      .= '<tr style="' . $row_bg . '">';

                // Teilnehmer-Zelle: nur beim ersten Durchlauf Name + Login,
                // danach nur Pass-Info + Zeitstempel
                if ($is_first) {
                    $html .= '<td rowspan="' . $pass_count_local . '" style="vertical-align:top;border-right:2px solid #dee2e6;">'
                           . '<strong>' . htmlspecialchars($name ?: $login) . '</strong>'
                           . '<br><small style="color:#999;">' . htmlspecialchars($login) . '</small>'
                           . ($pass_count_local > 1
                               ? '<br><small style="color:#6c757d;margin-top:4px;display:block;">'
                                 . $pass_count_local . ' ' . $this->txt('unit_passes') . '</small>'
                               : '')
                           . '</td>';
                }

                // Pass-Nummer + Datum
                $date_str = '';
                if (!empty($pass['submitted_at'])) {
                    $ts = strtotime($pass['submitted_at']);
                    if ($ts) {
                        $date_str = date('d.m.Y H:i', $ts);
                    }
                }

                // Trendpfeil gegenüber vorherigem Durchlauf
                $trend = '';
                if ($idx > 0) {
                    $prev_total = $totals_per_pass[$participant_passes[$idx - 1]['pass']];
                    $curr_total = $totals_per_pass[$pass['pass']];
                    if ($curr_total > $prev_total) {
                        $trend = ' <span style="color:#28a745;font-weight:bold;" title="' . $this->txt('trend_better') . '">▲</span>';
                    } elseif ($curr_total < $prev_total) {
                        $trend = ' <span style="color:#dc3545;font-weight:bold;" title="' . $this->txt('trend_worse') . '">▼</span>';
                    } else {
                        $trend = ' <span style="color:#6c757d;" title="' . $this->txt('trend_equal') . '">→</span>';
                    }
                }

                // Pass-Info-Zelle (erste Datenspalte)
                $html .= '<td style="white-space:nowrap;color:#555;font-size:0.85em;vertical-align:top;">'
                       . '<strong>' . $this->txt('lbl_pass') . ' ' . $pass_nr . '</strong>' . $trend
                       . ($date_str ? '<br><small>' . $date_str . '</small>' : '')
                       . '</td>';

                // Punkte je Gruppe
                foreach ($active_groups as $ag) {
                    $gid     = $ag['group']['id'];
                    $reached = 0.0;
                    $max     = $group_max[$gid];

                    foreach ($ag['qids'] as $qid) {
                        if (isset($questions[$qid])) {
                            $reached += (float) ($q_results[$qid] ?? 0.0);
                        }
                    }

                    // Für Ø nur letzten Durchlauf zählen
                    if ($is_last) {
                        $summary_reached[$gid] += $reached;
                    }

                    $pct    = $max > 0 ? ($reached / $max) * 100 : 0;
                    $ttype  = $ag['group']['threshold_type']  ?? 'percent';
                    $tval   = (float) ($ag['group']['threshold_value'] ?? 50);
                    $passed = $ttype === 'points' ? $reached >= $tval : $pct >= $tval;
                    $bg     = $passed ? '#d4edda' : '#f8d7da';
                    $label  = $passed ? '✓' : '✗';

                    $html .= '<td style="background:' . $bg . ';white-space:nowrap;vertical-align:top;">'
                           . '<strong>' . number_format($reached, 2) . ' ' . $this->txt('unit_pts') . '</strong>'
                           . '<br><small>' . $this->txt('lbl_of') . ' ' . number_format($max, 2) . ' ' . $this->txt('unit_pts')
                           . ' (' . number_format($pct, 1) . '%)</small>'
                           . '<br><small>' . $label . ' ' . ($passed ? $this->txt('status_passed') : $this->txt('status_failed')) . '</small>'
                           . '</td>';
                }

                // Nicht zugeordnete Fragen
                if ($has_ungrouped) {
                    $ug_reached = 0.0;
                    foreach ($ungrouped_qids as $qid) {
                        $ug_reached += (float) ($q_results[$qid] ?? 0.0);
                    }
                    if ($is_last) {
                        $summary_ungrouped += $ug_reached;
                    }
                    $ug_pct = $ungrouped_max > 0 ? ($ug_reached / $ungrouped_max) * 100 : 0;
                    $html .= '<td style="background:#fff3cd;white-space:nowrap;vertical-align:top;">'
                           . number_format($ug_reached, 2) . ' ' . $this->txt('unit_pts')
                           . '<br><small>' . $this->txt('lbl_of') . ' ' . number_format($ungrouped_max, 2) . ' ' . $this->txt('unit_pts')
                           . ' (' . number_format($ug_pct, 1) . '%)</small>'
                           . '</td>';
                }

                // Gesamt
                $total_reached = $totals_per_pass[$pass['pass']];
                if ($is_last) {
                    $summary_total_reached += $total_reached;
                }
                $total_pct = $test_total_max > 0 ? ($total_reached / $test_total_max) * 100 : 0;
                $html .= '<td style="white-space:nowrap;font-weight:bold;vertical-align:top;">'
                       . number_format($total_reached, 2) . ' ' . $this->txt('unit_pts')
                       . '<br><small>' . $this->txt('lbl_of') . ' ' . number_format($test_total_max, 2) . ' ' . $this->txt('unit_pts')
                       . ' (' . number_format($total_pct, 1) . '%)</small>'
                       . '</td>';

                $html .= '</tr>';
            }

            // Trennlinie nach jedem Teilnehmer (außer dem letzten)
            if ($aid !== array_key_last($by_participant)) {
                $col_count = 2 + count($active_groups) + ($has_ungrouped ? 1 : 0) + 1;
                $html .= '<tr><td colspan="' . $col_count . '" style="padding:0;border-top:2px solid #dee2e6;"></td></tr>';
            }
        }

        // Zusammenfassungszeile (Ø letzter Durchlauf je Teilnehmer)
        if ($participant_count > 0) {
            $col_span_name = 2; // Name + Durchlauf-Zelle
            $html .= '<tr style="background:#f8f9fa;font-style:italic;border-top:2px solid #adb5bd;">';
            $html .= '<td colspan="' . $col_span_name . '"><strong>' . $this->txt('avg_last_pass') . '</strong>'
                   . '<br><small>(' . $participant_count . ' ' . $this->txt('unit_participants') . ')</small></td>';

            foreach ($active_groups as $ag) {
                $gid     = $ag['group']['id'];
                $max     = $group_max[$gid];
                $avg     = $summary_reached[$gid] / $participant_count;
                $avg_pct = $max > 0 ? ($avg / $max) * 100 : 0;
                $html .= '<td style="white-space:nowrap;">'
                       . number_format($avg, 2) . ' ' . $this->txt('unit_pts')
                       . '<br><small>' . $this->txt('lbl_of') . ' ' . number_format($max, 2) . ' ' . $this->txt('unit_pts')
                       . ' (' . number_format($avg_pct, 1) . '%)</small>'
                       . '</td>';
            }

            if ($has_ungrouped) {
                $ug_avg     = $summary_ungrouped / $participant_count;
                $ug_avg_pct = $ungrouped_max > 0 ? ($ug_avg / $ungrouped_max) * 100 : 0;
                $html .= '<td style="background:#fff3cd;white-space:nowrap;">'
                       . number_format($ug_avg, 2) . ' ' . $this->txt('unit_pts')
                       . '<br><small>' . $this->txt('lbl_of') . ' ' . number_format($ungrouped_max, 2) . ' ' . $this->txt('unit_pts')
                       . ' (' . number_format($ug_avg_pct, 1) . '%)</small>'
                       . '</td>';
            }

            $total_avg     = $summary_total_reached / $participant_count;
            $total_avg_pct = $test_total_max > 0 ? ($total_avg / $test_total_max) * 100 : 0;
            $html .= '<td style="white-space:nowrap;font-weight:bold;">'
                   . number_format($total_avg, 2) . ' ' . $this->txt('unit_pts')
                   . '<br><small>' . $this->txt('lbl_of') . ' ' . number_format($test_total_max, 2) . ' ' . $this->txt('unit_pts')
                   . ' (' . number_format($total_avg_pct, 1) . '%)</small>'
                   . '</td>';
            $html .= '</tr>';
        }

        $html .= '</tbody></table>';
        $html .= '</div>';

        return $html;
    }

    // =========================================================================
    // Gruppe hinzufügen
    // =========================================================================

    private function addGroup(int $ref_id): void
    {
        $this->setupNavigation($ref_id);

        $form = new ilPropertyFormGUI();
        $form->setFormAction($this->proxyFormAction('saveGroup', ['ref_id' => $ref_id]));
        $form->setTitle($this->txt('form_new_group_title'));

        $name_input = new ilTextInputGUI($this->txt('group_name'), 'group_name');
        $name_input->setRequired(true);
        $name_input->setMaxLength(255);
        $form->addItem($name_input);

        $ref_hidden = new ilHiddenInputGUI('ref_id');
        $ref_hidden->setValue((string) $ref_id);
        $form->addItem($ref_hidden);

        $form->addCommandButton('saveGroup', $this->txt('btn_create_group'));
        $form->addCommandButton('show', $this->txt('btn_cancel'));

        $this->tpl->setContent($form->getHTML());
    }

    private function saveGroup(int $ref_id): void
    {
        $obj_id = ilObject::_lookupObjectId($ref_id);
        $name   = trim($_POST['group_name'] ?? '');

        if ($name === '') {
            $this->tpl->setOnScreenMessage('failure', $this->txt('err_empty_name'));
            $this->addGroup($ref_id);
            return;
        }

        $result   = $this->db->queryF(
            "SELECT MAX(position) AS max_pos FROM examgrouping_groups WHERE test_id = %s",
            ['integer'],
            [$obj_id]
        );
        $row      = $this->db->fetchAssoc($result);
        $position = (int) ($row['max_pos'] ?? 0) + 1;

        $new_id = $this->db->nextId('examgrouping_groups');
        $this->db->insert('examgrouping_groups', [
            'id'         => ['integer',   $new_id],
            'test_id'    => ['integer',   $obj_id],
            'name'       => ['text',      $name],
            'position'   => ['integer',   $position],
            'created_at' => ['timestamp', date('Y-m-d H:i:s')],
        ]);

        $this->tpl->setOnScreenMessage('success', sprintf($this->txt('msg_group_created'), htmlspecialchars($name)));
        $this->proxyRedirect('show', ['ref_id' => $ref_id]);
    }

    // =========================================================================
    // Gruppe löschen
    // =========================================================================

    private function deleteGroup(int $ref_id): void
    {
        $submitted_token = $_POST['examgrouping_delete_token'] ?? null;
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST'
            || !is_string($submitted_token)
            || !hash_equals($this->getDeleteToken(), $submitted_token)
        ) {
            http_response_code(403);
            $this->tpl->setOnScreenMessage('failure', $this->txt('no_permission'));
            return;
        }

        $group_id = (int) ($_POST['group_id'] ?? 0);
        $obj_id   = ilObject::_lookupObjectId($ref_id);

        if ($group_id > 0) {
            // Sicherheitsprüfung: Gruppe muss zu diesem Test gehören
            $result = $this->db->queryF(
                "SELECT id, name FROM examgrouping_groups WHERE id = %s AND test_id = %s",
                ['integer', 'integer'],
                [$group_id, $obj_id]
            );
            $group = $this->db->fetchAssoc($result);

            if ($group) {
                $this->db->manipulate(
                    "DELETE FROM examgrouping_items WHERE group_id = "
                    . $this->db->quote($group_id, 'integer')
                );
                $this->db->manipulate(
                    "DELETE FROM examgrp_pool_items WHERE group_id = "
                    . $this->db->quote($group_id, 'integer')
                );
                $this->db->manipulate(
                    "DELETE FROM examgrouping_groups WHERE id = "
                    . $this->db->quote($group_id, 'integer')
                );
                $this->tpl->setOnScreenMessage(
                    'success',
                    sprintf($this->txt('msg_group_deleted'), htmlspecialchars($group['name']))
                );
            }
        }

        $this->proxyRedirect('show', ['ref_id' => $ref_id]);
    }

    // =========================================================================
    // Gruppen-Einstellungen (Name + Schwellenwert)
    // =========================================================================

    private function editGroupSettings(int $ref_id): void
    {
        $group_id = (int) ($_GET['group_id'] ?? 0);
        $obj_id   = ilObject::_lookupObjectId($ref_id);

        if ($group_id <= 0) {
            $this->proxyRedirect('show', ['ref_id' => $ref_id]);
            return;
        }

        $result = $this->db->queryF(
            "SELECT id, name, threshold_type, threshold_value
             FROM examgrouping_groups WHERE id = %s AND test_id = %s",
            ['integer', 'integer'],
            [$group_id, $obj_id]
        );
        $group = $this->db->fetchAssoc($result);

        if (!$group) {
            $this->tpl->setOnScreenMessage('failure', $this->txt('err_group_not_found'));
            $this->proxyRedirect('show', ['ref_id' => $ref_id]);
            return;
        }

        $this->setupNavigation($ref_id);

        $form = new ilPropertyFormGUI();
        $form->setFormAction($this->proxyFormAction('saveGroupSettings', ['ref_id' => $ref_id, 'group_id' => $group_id]));
        $form->setTitle(sprintf($this->txt('form_settings_title'), htmlspecialchars($group['name'])));

        // Gruppenname
        $name_input = new ilTextInputGUI($this->txt('group_name'), 'group_name');
        $name_input->setRequired(true);
        $name_input->setMaxLength(255);
        $name_input->setValue($group['name']);
        $form->addItem($name_input);

        // Schwellenwert-Typ
        $section = new ilFormSectionHeaderGUI();
        $section->setTitle($this->txt('threshold_section'));
        $form->addItem($section);

        $type_select = new ilSelectInputGUI($this->txt('threshold_type_label'), 'threshold_type');
        $type_select->setOptions([
            'percent' => $this->txt('threshold_percent'),
            'points'  => $this->txt('threshold_points'),
        ]);
        $type_select->setValue($group['threshold_type'] ?? 'percent');
        $form->addItem($type_select);

        $val_input = new ilNumberInputGUI($this->txt('threshold_value_label'), 'threshold_value');
        $val_input->setRequired(true);
        $val_input->setMinValue(0);
        $val_input->setDecimals(2);
        $val_input->setValue((string) ($group['threshold_value'] ?? 50));
        $val_input->setInfo($this->txt('threshold_value_info'));
        $form->addItem($val_input);

        $ref_hidden = new ilHiddenInputGUI('ref_id');
        $ref_hidden->setValue((string) $ref_id);
        $form->addItem($ref_hidden);

        $gid_hidden = new ilHiddenInputGUI('group_id');
        $gid_hidden->setValue((string) $group_id);
        $form->addItem($gid_hidden);

        $form->addCommandButton('saveGroupSettings', $this->txt('btn_save'));
        $form->addCommandButton('show', $this->txt('btn_cancel'));

        $this->tpl->setContent($form->getHTML());
    }

    private function saveGroupSettings(int $ref_id): void
    {
        $group_id = (int) ($_POST['group_id'] ?? 0);
        $obj_id   = ilObject::_lookupObjectId($ref_id);

        if ($group_id <= 0) {
            $this->proxyRedirect('show', ['ref_id' => $ref_id]);
            return;
        }

        // Sicherheitsprüfung
        $result = $this->db->queryF(
            "SELECT id FROM examgrouping_groups WHERE id = %s AND test_id = %s",
            ['integer', 'integer'],
            [$group_id, $obj_id]
        );
        if ($this->db->numRows($result) === 0) {
            $this->tpl->setOnScreenMessage('failure', $this->txt('err_group_not_found'));
            $this->proxyRedirect('show', ['ref_id' => $ref_id]);
            return;
        }

        $name       = trim($_POST['group_name']       ?? '');
        $ttype      = in_array($_POST['threshold_type'] ?? '', ['percent', 'points'])
                      ? $_POST['threshold_type']
                      : 'percent';
        $tval       = max(0.0, (float) str_replace(',', '.', $_POST['threshold_value'] ?? '50'));

        if ($name === '') {
            $this->tpl->setOnScreenMessage('failure', $this->txt('err_name_empty2'));
            $this->proxyRedirect('editGroupSettings', ['ref_id' => $ref_id, 'group_id' => $group_id]);
            return;
        }

        $this->db->update(
            'examgrouping_groups',
            [
                'name'            => ['text',    $name],
                'threshold_type'  => ['text',    $ttype],
                'threshold_value' => ['float',   $tval],
            ],
            ['id' => ['integer', $group_id]]
        );

        $this->tpl->setOnScreenMessage('success', $this->txt('msg_settings_saved'));
        $this->proxyRedirect('show', ['ref_id' => $ref_id]);
    }

    // =========================================================================
    // Fragen einer Gruppe bearbeiten
    // =========================================================================

    private function editGroup(int $ref_id): void
    {
        $obj_id = ilObject::_lookupObjectId($ref_id);
        if ($this->isRandomTest($obj_id)) {
            $this->editGroupPools($ref_id, $obj_id);
            return;
        }
        $this->editGroupQuestions($ref_id, $obj_id);
    }

    private function editGroupQuestions(int $ref_id, int $obj_id): void
    {
        $group_id = (int) ($_GET['group_id'] ?? 0);

        if ($group_id <= 0) {
            $this->proxyRedirect('show', ['ref_id' => $ref_id]);
            return;
        }

        $result = $this->db->queryF(
            "SELECT id, name FROM examgrouping_groups WHERE id = %s AND test_id = %s",
            ['integer', 'integer'],
            [$group_id, $obj_id]
        );
        $group = $this->db->fetchAssoc($result);

        if (!$group) {
            $this->tpl->setOnScreenMessage('failure', $this->txt('err_group_not_found'));
            $this->proxyRedirect('show', ['ref_id' => $ref_id]);
            return;
        }

        $this->setupNavigation($ref_id);

        $questions    = $this->getTestQuestions($obj_id);
        $assigned     = $this->getGroupQuestions($group_id);
        $assigned_set = array_flip($assigned);

        $form = new ilPropertyFormGUI();
        $form->setFormAction($this->proxyFormAction('saveGroupQuestions', ['ref_id' => $ref_id, 'group_id' => $group_id]));
        $form->setTitle(sprintf($this->txt('form_assign_questions_title'), htmlspecialchars($group['name'])));

        if (empty($questions)) {
            $info = new ilCustomInputGUI('');
            $info->setHtml('<p style="color:#999;">' . $this->txt('no_questions') . '</p>');
            $form->addItem($info);
        } else {
            $section = new ilFormSectionHeaderGUI();
            $section->setTitle($this->txt('select_questions_section'));
            $form->addItem($section);

            foreach ($questions as $qid => $q) {
                $cb = new ilCheckboxInputGUI(
                    'F' . $q['sequence'] . ': ' . htmlspecialchars($q['title'])
                    . ' (' . number_format((float) $q['points'], 2) . ' ' . $this->txt('unit_pts') . ')',
                    'question_' . $qid
                );
                $cb->setChecked(isset($assigned_set[$qid]));
                $form->addItem($cb);
            }
        }

        $ref_hidden = new ilHiddenInputGUI('ref_id');
        $ref_hidden->setValue((string) $ref_id);
        $form->addItem($ref_hidden);

        $gid_hidden = new ilHiddenInputGUI('group_id');
        $gid_hidden->setValue((string) $group_id);
        $form->addItem($gid_hidden);

        $form->addCommandButton('saveGroupQuestions', $this->txt('btn_save'));
        $form->addCommandButton('show', $this->txt('btn_cancel'));

        $this->tpl->setContent($form->getHTML());
    }

    private function editGroupPools(int $ref_id, int $obj_id): void
    {
        $group_id = (int) ($_GET['group_id'] ?? 0);

        if ($group_id <= 0) {
            $this->proxyRedirect('show', ['ref_id' => $ref_id]);
            return;
        }

        $result = $this->db->queryF(
            "SELECT id, name FROM examgrouping_groups WHERE id = %s AND test_id = %s",
            ['integer', 'integer'],
            [$group_id, $obj_id]
        );
        $group = $this->db->fetchAssoc($result);

        if (!$group) {
            $this->tpl->setOnScreenMessage('failure', $this->txt('err_group_not_found'));
            $this->proxyRedirect('show', ['ref_id' => $ref_id]);
            return;
        }

        $this->setupNavigation($ref_id);

        $pools        = $this->getTestPools($obj_id);
        $assigned     = $this->getGroupPools($group_id);
        $assigned_set = array_flip($assigned);

        $form = new ilPropertyFormGUI();
        $form->setFormAction($this->proxyFormAction('saveGroupQuestions', ['ref_id' => $ref_id, 'group_id' => $group_id]));
        $form->setTitle(sprintf($this->txt('form_assign_pools_title'), htmlspecialchars($group['name'])));

        $section = new ilFormSectionHeaderGUI();
        $section->setTitle($this->txt('select_pools_section'));
        $form->addItem($section);

        foreach ($pools as $pool_id => $pool) {
            $cb = new ilCheckboxInputGUI(
                htmlspecialchars($pool['title'])
                . ' (' . $pool['quest_amount'] . ' ' . $this->txt('unit_questions_per_participant') . ')',
                'pool_' . $pool_id
            );
            $cb->setChecked(isset($assigned_set[$pool_id]));
            $form->addItem($cb);
        }

        $ref_hidden = new ilHiddenInputGUI('ref_id');
        $ref_hidden->setValue((string) $ref_id);
        $form->addItem($ref_hidden);

        $gid_hidden = new ilHiddenInputGUI('group_id');
        $gid_hidden->setValue((string) $group_id);
        $form->addItem($gid_hidden);

        $form->addCommandButton('saveGroupQuestions', $this->txt('btn_save'));
        $form->addCommandButton('show', $this->txt('btn_cancel'));

        $this->tpl->setContent($form->getHTML());
    }

    private function saveGroupQuestions(int $ref_id): void
    {
        $obj_id = ilObject::_lookupObjectId($ref_id);
        if ($this->isRandomTest($obj_id)) {
            $this->saveGroupPools($ref_id, $obj_id);
            return;
        }
        $this->saveGroupFixedQuestions($ref_id, $obj_id);
    }

    private function saveGroupFixedQuestions(int $ref_id, int $obj_id): void
    {
        $group_id = (int) ($_POST['group_id'] ?? 0);

        if ($group_id <= 0) {
            $this->proxyRedirect('show', ['ref_id' => $ref_id]);
            return;
        }

        $result = $this->db->queryF(
            "SELECT id FROM examgrouping_groups WHERE id = %s AND test_id = %s",
            ['integer', 'integer'],
            [$group_id, $obj_id]
        );
        if ($this->db->numRows($result) === 0) {
            $this->tpl->setOnScreenMessage('failure', $this->txt('err_group_not_found'));
            $this->proxyRedirect('show', ['ref_id' => $ref_id]);
            return;
        }

        $questions = $this->getTestQuestions($obj_id);

        $this->db->manipulate(
            "DELETE FROM examgrouping_items WHERE group_id = "
            . $this->db->quote($group_id, 'integer')
        );

        $count = 0;
        foreach ($questions as $qid => $q) {
            if (!empty($_POST['question_' . $qid])) {
                $new_id = $this->db->nextId('examgrouping_items');
                $this->db->insert('examgrouping_items', [
                    'id'          => ['integer', $new_id],
                    'group_id'    => ['integer', $group_id],
                    'question_id' => ['integer', $qid],
                ]);
                $count++;
            }
        }

        $this->tpl->setOnScreenMessage('success', sprintf($this->txt('msg_questions_assigned'), $count));
        $this->proxyRedirect('show', ['ref_id' => $ref_id]);
    }

    private function saveGroupPools(int $ref_id, int $obj_id): void
    {
        $group_id = (int) ($_POST['group_id'] ?? 0);

        if ($group_id <= 0) {
            $this->proxyRedirect('show', ['ref_id' => $ref_id]);
            return;
        }

        $result = $this->db->queryF(
            "SELECT id FROM examgrouping_groups WHERE id = %s AND test_id = %s",
            ['integer', 'integer'],
            [$group_id, $obj_id]
        );
        if ($this->db->numRows($result) === 0) {
            $this->tpl->setOnScreenMessage('failure', $this->txt('err_group_not_found'));
            $this->proxyRedirect('show', ['ref_id' => $ref_id]);
            return;
        }

        $pools = $this->getTestPools($obj_id);

        $this->db->manipulate(
            "DELETE FROM examgrp_pool_items WHERE group_id = "
            . $this->db->quote($group_id, 'integer')
        );

        $count = 0;
        foreach ($pools as $pool_id => $pool) {
            if (!empty($_POST['pool_' . $pool_id])) {
                $new_id = $this->db->nextId('examgrp_pool_items');
                $this->db->insert('examgrp_pool_items', [
                    'id'       => ['integer', $new_id],
                    'group_id' => ['integer', $group_id],
                    'pool_id'  => ['integer', $pool_id],
                ]);
                $count++;
            }
        }

        $this->tpl->setOnScreenMessage('success', sprintf($this->txt('msg_pools_assigned'), $count));
        $this->proxyRedirect('show', ['ref_id' => $ref_id]);
    }

    // =========================================================================
    // Pool-basierte Gruppen-Übersicht (Zufallstest)
    // =========================================================================

    private function buildPoolGroupsSection(int $ref_id, int $obj_id, array $groups, array $pools): string
    {
        $add_link = $this->proxyLink('addGroup', ['ref_id' => $ref_id]);

        $html  = '<div style="margin-bottom:2rem;">';
        $html .= '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:0.5rem;">';
        $html .= '<h3 style="margin:0;">' . $this->txt('groups_heading') . '</h3>';
        $html .= '<a href="' . htmlspecialchars($add_link) . '" class="btn btn-primary">' . $this->txt('btn_new_group') . '</a>';
        $html .= '</div>';
        $html .= '<p class="text-muted" style="margin-bottom:1rem;">'
               . $this->txt('pool_intro')
               . '</p>';

        if (empty($groups)) {
            $html .= '<p class="text-muted">' . $this->txt('no_groups_hint') . '</p>';
        } else {
            $html .= '<table class="table table-striped" style="width:100%;">';
            $html .= '<thead><tr>'
                   . '<th>' . $this->txt('th_group') . '</th>'
                   . '<th>' . $this->txt('th_assigned_pools') . '</th>'
                   . '<th>' . $this->txt('th_threshold') . '</th>'
                   . '<th>' . $this->txt('th_actions') . '</th>'
                   . '</tr></thead><tbody>';

            foreach ($groups as $group) {
                $assigned_pool_ids = $this->getGroupPools($group['id']);
                $pool_labels = [];
                foreach ($assigned_pool_ids as $pid) {
                    if (isset($pools[$pid])) {
                        $pool_labels[] = htmlspecialchars($pools[$pid]['title'])
                            . ' <small style="color:#666;">(' . $pools[$pid]['quest_amount'] . ' ' . $this->txt('unit_questions_short') . ')</small>';
                    }
                }

                $edit_link     = $this->proxyLink('editGroup',         ['ref_id' => $ref_id, 'group_id' => $group['id']]);
                $settings_link = $this->proxyLink('editGroupSettings', ['ref_id' => $ref_id, 'group_id' => $group['id']]);

                $pool_display = empty($pool_labels)
                    ? '<em style="color:#999;">' . $this->txt('no_pools_assigned') . '</em>'
                    : implode('<br>', $pool_labels);

                $ttype = $group['threshold_type']  ?? 'percent';
                $tval  = $group['threshold_value'] ?? 50.0;
                $threshold_display = $ttype === 'points'
                    ? number_format((float) $tval, 2) . ' ' . $this->txt('unit_pts')
                    : number_format((float) $tval, 0) . '%';

                $html .= '<tr>';
                $html .= '<td><strong>' . htmlspecialchars($group['name']) . '</strong></td>';
                $html .= '<td>' . $pool_display . '</td>';
                $html .= '<td>' . htmlspecialchars($threshold_display) . '</td>';
                $html .= '<td style="white-space:nowrap;">';

                $html .= '<a href="' . htmlspecialchars($settings_link) . '" class="btn btn-sm btn-default">' . $this->txt('btn_settings') . '</a> ';
                $html .= '<a href="' . htmlspecialchars($edit_link) . '" class="btn btn-sm btn-default">' . $this->txt('btn_pools') . '</a> ';
                $html .= $this->renderDeleteForm($ref_id, (int) $group['id'], $group['name']);
                $html .= '</td>';
                $html .= '</tr>';
            }

            $html .= '</tbody></table>';
        }

        $html .= '</div>';
        return $html;
    }

    // =========================================================================
    // Pool-basierte Ergebnisse (Zufallstest)
    // =========================================================================

    private function buildRandomResultsSection(int $ref_id, int $obj_id, array $groups, array $pools): string
    {
        if (empty($groups)) {
            return '';
        }

        $active_groups = [];
        foreach ($groups as $group) {
            $pool_ids = $this->getGroupPools($group['id']);
            if (!empty($pool_ids)) {
                $active_groups[] = ['group' => $group, 'pool_ids' => $pool_ids];
            }
        }

        $html  = '<hr>';
        $html .= '<h3>' . $this->txt('results_heading') . '</h3>';

        if (empty($active_groups)) {
            $html .= '<p class="text-muted">' . $this->txt('assign_pools_hint') . '</p>';
            return $html;
        }

        $passes = $this->getSubmittedPassesRandom($obj_id);

        if (empty($passes)) {
            $html .= '<p class="text-muted">' . $this->txt('no_passes') . '</p>';
            return $html;
        }

        // Alle Pool-IDs die einer Gruppe zugeordnet sind
        $all_grouped_pool_ids = [];
        foreach ($active_groups as $ag) {
            foreach ($ag['pool_ids'] as $pid) {
                $all_grouped_pool_ids[$pid] = true;
            }
        }
        $has_ungrouped = count($all_grouped_pool_ids) < count($pools);

        // Export-Button
        $export_link = $this->proxyLink('exportResults', ['ref_id' => $ref_id]);
        $html .= '<div style="text-align:right;margin-bottom:0.5rem;">'
               . '<a href="' . htmlspecialchars($export_link) . '" class="btn btn-default btn-sm">&#11015; ' . $this->txt('btn_export_csv') . '</a>'
               . '</div>';

        // Tabellenkopf
        $html .= '<div style="overflow-x:auto;">';
        $html .= '<table class="table table-sm table-bordered">';
        $html .= '<thead><tr>';
        $html .= '<th>' . $this->txt('th_participant') . '</th>';
        $html .= '<th style="white-space:nowrap;">' . $this->txt('th_pass') . '</th>';

        foreach ($active_groups as $ag) {
            $ttype = $ag['group']['threshold_type']  ?? 'percent';
            $tval  = (float) ($ag['group']['threshold_value'] ?? 50);
            $threshold_label = $ttype === 'points'
                ? $this->txt('lbl_from') . ' ' . number_format($tval, 2) . ' ' . $this->txt('unit_pts')
                : $this->txt('lbl_from') . ' ' . number_format($tval, 0) . '%';
            $pool_names = [];
            foreach ($ag['pool_ids'] as $pid) {
                if (isset($pools[$pid])) {
                    $pool_names[] = htmlspecialchars($pools[$pid]['title']);
                }
            }
            $html .= '<th style="white-space:nowrap;">'
                   . htmlspecialchars($ag['group']['name'])
                   . '<br><small style="font-weight:normal;color:#666;">' . implode(', ', $pool_names) . '</small>'
                   . '<br><small style="color:#555;">✓ ' . $threshold_label . '</small>'
                   . '</th>';
        }

        if ($has_ungrouped) {
            $html .= '<th style="white-space:nowrap;color:#856404;background:#fff3cd;">'
                   . $this->txt('ungrouped') . '</th>';
        }

        $html .= '<th>' . $this->txt('th_total') . '</th>';
        $html .= '</tr></thead><tbody>';

        // Passes nach Teilnehmer gruppieren
        $by_participant = [];
        foreach ($passes as $pass) {
            $aid = $pass['active_id'];
            if (!isset($by_participant[$aid])) {
                $by_participant[$aid] = [
                    'firstname' => $pass['firstname'],
                    'lastname'  => $pass['lastname'],
                    'login'     => $pass['login'],
                    'passes'    => [],
                ];
            }
            $by_participant[$aid]['passes'][] = $pass;
        }

        // Akkumulatoren für Ø-Zeile
        $summary_reached       = array_fill_keys(array_column(array_column($active_groups, 'group'), 'id'), 0.0);
        $summary_max           = array_fill_keys(array_column(array_column($active_groups, 'group'), 'id'), 0.0);
        $summary_ungrouped_r   = 0.0;
        $summary_ungrouped_m   = 0.0;
        $summary_total_reached = 0.0;
        $summary_total_max     = 0.0;
        $participant_count     = count($by_participant);

        foreach ($by_participant as $aid => $participant) {
            $participant_passes = $participant['passes'];
            $pass_count_local   = count($participant_passes);
            $name  = trim(($participant['firstname'] ?? '') . ' ' . ($participant['lastname'] ?? ''));
            $login = $participant['login'] ?? $this->txt('anon');

            // Gesamtpunkte je Pass (für Trendpfeil) via alle Fragen des Teilnehmers
            $totals_per_pass = [];
            foreach ($participant_passes as $p) {
                $res = $this->getRandomGroupResults($p['active_id'], $p['pass'], array_keys($pools));
                $totals_per_pass[$p['pass']] = $res;
            }

            foreach ($participant_passes as $idx => $pass) {
                $is_first = ($idx === 0);
                $is_last  = ($idx === $pass_count_local - 1);
                $pass_nr  = $pass['pass'] + 1;

                $row_bg = $is_first ? '' : 'background:#fafafa;';
                $html  .= '<tr style="' . $row_bg . '">';

                if ($is_first) {
                    $html .= '<td rowspan="' . $pass_count_local . '" style="vertical-align:top;border-right:2px solid #dee2e6;">'
                           . '<strong>' . htmlspecialchars($name ?: $login) . '</strong>'
                           . '<br><small style="color:#999;">' . htmlspecialchars($login) . '</small>'
                           . ($pass_count_local > 1
                               ? '<br><small style="color:#6c757d;margin-top:4px;display:block;">'
                                 . $pass_count_local . ' ' . $this->txt('unit_passes') . '</small>'
                               : '')
                           . '</td>';
                }

                // Pass-Info + Trendpfeil
                $date_str = '';
                if (!empty($pass['submitted_at'])) {
                    $ts = strtotime($pass['submitted_at']);
                    if ($ts) {
                        $date_str = date('d.m.Y H:i', $ts);
                    }
                }
                $trend = '';
                if ($idx > 0) {
                    $prev = $totals_per_pass[$participant_passes[$idx - 1]['pass']]['reached'];
                    $curr = $totals_per_pass[$pass['pass']]['reached'];
                    if ($curr > $prev) {
                        $trend = ' <span style="color:#28a745;font-weight:bold;" title="' . $this->txt('trend_better') . '">▲</span>';
                    } elseif ($curr < $prev) {
                        $trend = ' <span style="color:#dc3545;font-weight:bold;" title="' . $this->txt('trend_worse') . '">▼</span>';
                    } else {
                        $trend = ' <span style="color:#6c757d;" title="' . $this->txt('trend_equal_short') . '">→</span>';
                    }
                }
                $html .= '<td style="white-space:nowrap;color:#555;font-size:0.85em;vertical-align:top;">'
                       . '<strong>' . $this->txt('lbl_pass') . ' ' . $pass_nr . '</strong>' . $trend
                       . ($date_str ? '<br><small>' . $date_str . '</small>' : '')
                       . '</td>';

                // Punkte je Gruppe
                foreach ($active_groups as $ag) {
                    $gid = $ag['group']['id'];
                    $res = $this->getRandomGroupResults($pass['active_id'], $pass['pass'], $ag['pool_ids']);
                    $reached = $res['reached'];
                    $max     = $res['max'];

                    if ($is_last) {
                        $summary_reached[$gid] += $reached;
                        $summary_max[$gid]     += $max;
                    }

                    $pct    = $max > 0 ? ($reached / $max) * 100 : 0;
                    $ttype  = $ag['group']['threshold_type']  ?? 'percent';
                    $tval   = (float) ($ag['group']['threshold_value'] ?? 50);
                    $passed = $ttype === 'points' ? $reached >= $tval : ($max > 0 && $pct >= $tval);
                    $bg     = $max > 0 ? ($passed ? '#d4edda' : '#f8d7da') : '#f8f9fa';
                    $label  = $max > 0 ? ($passed ? '✓ ' . $this->txt('status_passed') : '✗ ' . $this->txt('status_failed')) : '–';

                    $html .= '<td style="background:' . $bg . ';white-space:nowrap;vertical-align:top;">';
                    if ($max > 0) {
                        $html .= '<strong>' . number_format($reached, 2) . ' ' . $this->txt('unit_pts') . '</strong>'
                               . '<br><small>' . $this->txt('lbl_of') . ' ' . number_format($max, 2) . ' ' . $this->txt('unit_pts')
                               . ' (' . number_format($pct, 1) . '%)</small>'
                               . '<br><small>' . $label . '</small>';
                    } else {
                        $html .= '<em style="color:#999;">' . $this->txt('no_questions_short') . '</em>';
                    }
                    $html .= '</td>';
                }

                // Nicht zugeordnete Pools
                if ($has_ungrouped) {
                    $ungrouped_pool_ids = array_values(array_diff(array_keys($pools), array_keys($all_grouped_pool_ids)));
                    $ug_res = $this->getRandomGroupResults($pass['active_id'], $pass['pass'], $ungrouped_pool_ids);
                    if ($is_last) {
                        $summary_ungrouped_r += $ug_res['reached'];
                        $summary_ungrouped_m += $ug_res['max'];
                    }
                    $ug_pct = $ug_res['max'] > 0 ? ($ug_res['reached'] / $ug_res['max']) * 100 : 0;
                    $html .= '<td style="background:#fff3cd;white-space:nowrap;vertical-align:top;">'
                           . number_format($ug_res['reached'], 2) . ' ' . $this->txt('unit_pts')
                           . ($ug_res['max'] > 0
                               ? '<br><small>' . $this->txt('lbl_of') . ' ' . number_format($ug_res['max'], 2) . ' ' . $this->txt('unit_pts')
                                 . ' (' . number_format($ug_pct, 1) . '%)</small>'
                               : '<br><small>—</small>')
                           . '</td>';
                }

                // Gesamt
                $total = $totals_per_pass[$pass['pass']];
                if ($is_last) {
                    $summary_total_reached += $total['reached'];
                    $summary_total_max     += $total['max'];
                }
                $total_pct = $total['max'] > 0 ? ($total['reached'] / $total['max']) * 100 : 0;
                $html .= '<td style="white-space:nowrap;font-weight:bold;vertical-align:top;">'
                       . number_format($total['reached'], 2) . ' ' . $this->txt('unit_pts')
                       . ($total['max'] > 0
                           ? '<br><small>' . $this->txt('lbl_of') . ' ' . number_format($total['max'], 2) . ' ' . $this->txt('unit_pts')
                             . ' (' . number_format($total_pct, 1) . '%)</small>'
                           : '')
                       . '</td>';

                $html .= '</tr>';
            }

            if ($aid !== array_key_last($by_participant)) {
                $col_count = 2 + count($active_groups) + ($has_ungrouped ? 1 : 0) + 1;
                $html .= '<tr><td colspan="' . $col_count . '" style="padding:0;border-top:2px solid #dee2e6;"></td></tr>';
            }
        }

        // Ø-Zeile
        if ($participant_count > 0) {
            $html .= '<tr style="background:#f8f9fa;font-style:italic;border-top:2px solid #adb5bd;">';
            $html .= '<td colspan="2"><strong>' . $this->txt('avg_last_pass') . '</strong>'
                   . '<br><small>(' . $participant_count . ' ' . $this->txt('unit_participants') . ')</small></td>';

            foreach ($active_groups as $ag) {
                $gid     = $ag['group']['id'];
                $avg_r   = $summary_reached[$gid] / $participant_count;
                $avg_m   = $summary_max[$gid]     / $participant_count;
                $avg_pct = $avg_m > 0 ? ($avg_r / $avg_m) * 100 : 0;
                $html .= '<td style="white-space:nowrap;">'
                       . number_format($avg_r, 2) . ' ' . $this->txt('unit_pts')
                       . ($avg_m > 0
                           ? '<br><small>' . $this->txt('lbl_of_avg') . ' ' . number_format($avg_m, 2) . ' ' . $this->txt('unit_pts')
                             . ' (' . number_format($avg_pct, 1) . '%)</small>'
                           : '')
                       . '</td>';
            }

            if ($has_ungrouped) {
                $ug_avg_r   = $summary_ungrouped_r / $participant_count;
                $ug_avg_m   = $summary_ungrouped_m / $participant_count;
                $ug_avg_pct = $ug_avg_m > 0 ? ($ug_avg_r / $ug_avg_m) * 100 : 0;
                $html .= '<td style="background:#fff3cd;white-space:nowrap;">'
                       . number_format($ug_avg_r, 2) . ' ' . $this->txt('unit_pts')
                       . ($ug_avg_m > 0
                           ? '<br><small>' . $this->txt('lbl_of_avg') . ' ' . number_format($ug_avg_m, 2) . ' ' . $this->txt('unit_pts')
                             . ' (' . number_format($ug_avg_pct, 1) . '%)</small>'
                           : '')
                       . '</td>';
            }

            $t_avg_r   = $summary_total_reached / $participant_count;
            $t_avg_m   = $summary_total_max     / $participant_count;
            $t_avg_pct = $t_avg_m > 0 ? ($t_avg_r / $t_avg_m) * 100 : 0;
            $html .= '<td style="white-space:nowrap;font-weight:bold;">'
                   . number_format($t_avg_r, 2) . ' ' . $this->txt('unit_pts')
                   . ($t_avg_m > 0
                       ? '<br><small>' . $this->txt('lbl_of_avg') . ' ' . number_format($t_avg_m, 2) . ' ' . $this->txt('unit_pts')
                         . ' (' . number_format($t_avg_pct, 1) . '%)</small>'
                       : '')
                   . '</td>';
            $html .= '</tr>';
        }

        $html .= '</tbody></table></div>';
        return $html;
    }

    // =========================================================================
    // CSV-Export
    // =========================================================================

    private function csvCell($value): string
    {
        $cell = (string) $value;
        // Tabellenprogramme werten auch in Anführungszeichen stehende CSV-Felder
        // als Formeln aus. Das Apostroph erzwingt Text, auch nach Leerzeichen.
        if (preg_match('/^[\x00-\x20]*[=+\-@]/', $cell) || preg_match('/^[\t\r\n]/', $cell)) {
            return "'" . $cell;
        }
        return $cell;
    }

    private function exportResults(int $ref_id): void
    {
        $obj_id = ilObject::_lookupObjectId($ref_id);

        if ($this->isRandomTest($obj_id)) {
            $this->exportRandomResults($ref_id, $obj_id);
            return;
        }

        if (ilObject::_lookupType($obj_id) !== 'tst') {
            $this->tpl->setOnScreenMessage('failure', $this->txt('export_not_possible'));
            $this->proxyRedirect('show', ['ref_id' => $ref_id]);
            return;
        }

        $questions     = $this->getTestQuestions($obj_id);
        $groups        = $this->getGroupsForTest($obj_id);
        $active_groups = [];
        foreach ($groups as $group) {
            $qids = $this->getGroupQuestions($group['id']);
            if (!empty($qids)) {
                $active_groups[] = ['group' => $group, 'qids' => $qids];
            }
        }

        // Nicht zugeordnete Fragen
        $all_grouped_qids = [];
        foreach ($active_groups as $ag) {
            foreach ($ag['qids'] as $qid) {
                $all_grouped_qids[$qid] = true;
            }
        }
        $ungrouped_qids = [];
        $ungrouped_max  = 0.0;
        foreach ($questions as $qid => $q) {
            if (!isset($all_grouped_qids[$qid])) {
                $ungrouped_qids[] = $qid;
                $ungrouped_max   += (float) $q['points'];
            }
        }
        $has_ungrouped = !empty($ungrouped_qids);

        // Max-Punkte je Gruppe
        $group_max = [];
        foreach ($active_groups as $ag) {
            $max_pts = 0.0;
            foreach ($ag['qids'] as $qid) {
                if (isset($questions[$qid])) {
                    $max_pts += (float) $questions[$qid]['points'];
                }
            }
            $group_max[$ag['group']['id']] = $max_pts;
        }

        $passes     = $this->getSubmittedPasses($obj_id);
        $test_title = ilObject::_lookupTitle($obj_id);

        // Eine Zeile pro Kandidat: nur der letzte Durchlauf zählt
        $last_passes = $this->getLastPassPerParticipant($passes);

        // ── CSV-Header aufbauen ──────────────────────────────────────────────
        // Name | Matrikelnummer | Kennung | je Gruppe: Punkte + % | Gesamtpunktzahl

        $header = [$this->txt('csv_name'), $this->txt('csv_matriculation'), $this->txt('csv_login')];

        foreach ($active_groups as $ag) {
            $gname    = $ag['group']['name'];
            $header[] = $gname . ' (' . $this->txt('unit_pts') . ')';
            $header[] = $gname . ' (%)';
        }

        if ($has_ungrouped) {
            $header[] = $this->txt('ungrouped') . ' (' . $this->txt('unit_pts') . ')';
            $header[] = $this->txt('ungrouped') . ' (%)';
        }

        $header[] = $this->txt('csv_total_points');

        // ── HTTP-Download-Header ─────────────────────────────────────────────
        $safe_title = preg_replace('/[^a-zA-Z0-9_-]/', '_', $test_title);
        $filename   = 'fragengruppierung_' . $safe_title . '_' . date('Ymd_His') . '.csv';

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Pragma: no-cache');
        header('Expires: 0');

        $out = fopen('php://output', 'w');
        fputs($out, "\xEF\xBB\xBF"); // UTF-8 BOM für Excel
        fputcsv($out, array_map([$this, 'csvCell'], $header), ';');

        // ── Datenzeilen ──────────────────────────────────────────────────────
        foreach ($last_passes as $pass) {
            $q_results = $this->getQuestionResults($pass['active_id'], $pass['pass']);

            $name  = trim(($pass['firstname'] ?? '') . ' ' . ($pass['lastname'] ?? ''));
            $login = $pass['login'] ?? '';
            // Name inkl. Anmeldename, z.B. "Max Mustermann (mmustermann)"
            $display_name = $name !== '' ? $name . ' (' . $login . ')' : $login;
            $row   = [$display_name, $pass['matriculation'] ?? '', $login];

            foreach ($active_groups as $ag) {
                $max     = $group_max[$ag['group']['id']];
                $reached = 0.0;
                foreach ($ag['qids'] as $qid) {
                    if (isset($questions[$qid])) {
                        $reached += (float) ($q_results[$qid] ?? 0.0);
                    }
                }

                $pct   = $max > 0 ? ($reached / $max) * 100 : 0;
                $row[] = number_format($reached, 2, ',', '');
                $row[] = number_format($pct,     1, ',', '');
            }

            if ($has_ungrouped) {
                $ug_reached = 0.0;
                foreach ($ungrouped_qids as $qid) {
                    $ug_reached += (float) ($q_results[$qid] ?? 0.0);
                }
                $ug_pct = $ungrouped_max > 0 ? ($ug_reached / $ungrouped_max) * 100 : 0;
                $row[]  = number_format($ug_reached, 2, ',', '');
                $row[]  = number_format($ug_pct,     1, ',', '');
            }

            // Gesamt: jede Frage einmal zählen (nicht Gruppen-Summen, da Fragen in mehreren Gruppen sein können)
            $total_reached = 0.0;
            foreach ($questions as $qid => $q) {
                $total_reached += (float) ($q_results[$qid] ?? 0.0);
            }
            $row[] = number_format($total_reached, 2, ',', '');

            fputcsv($out, array_map([$this, 'csvCell'], $row), ';');
        }

        fclose($out);
        exit();
    }

    private function exportRandomResults(int $ref_id, int $obj_id): void
    {
        $pools  = $this->getTestPools($obj_id);
        $groups = $this->getGroupsForTest($obj_id);

        $active_groups = [];
        foreach ($groups as $group) {
            $pool_ids = $this->getGroupPools($group['id']);
            if (!empty($pool_ids)) {
                $active_groups[] = ['group' => $group, 'pool_ids' => $pool_ids];
            }
        }

        $all_grouped_pool_ids = [];
        foreach ($active_groups as $ag) {
            foreach ($ag['pool_ids'] as $pid) {
                $all_grouped_pool_ids[$pid] = true;
            }
        }
        $ungrouped_pool_ids = array_values(array_diff(array_keys($pools), array_keys($all_grouped_pool_ids)));
        $has_ungrouped = !empty($ungrouped_pool_ids);

        $passes     = $this->getSubmittedPassesRandom($obj_id);
        $test_title = ilObject::_lookupTitle($obj_id);

        // Eine Zeile pro Kandidat: nur der letzte Durchlauf zählt
        $last_passes = $this->getLastPassPerParticipant($passes);

        // Name | Matrikelnummer | Kennung | je Gruppe: Punkte + % | Gesamtpunktzahl
        $header = [$this->txt('csv_name'), $this->txt('csv_matriculation'), $this->txt('csv_login')];
        foreach ($active_groups as $ag) {
            $gname    = $ag['group']['name'];
            $header[] = $gname . ' (' . $this->txt('unit_pts') . ')';
            $header[] = $gname . ' (%)';
        }
        if ($has_ungrouped) {
            $header[] = $this->txt('ungrouped') . ' (' . $this->txt('unit_pts') . ')';
            $header[] = $this->txt('ungrouped') . ' (%)';
        }
        $header[] = $this->txt('csv_total_points');

        $safe_title = preg_replace('/[^a-zA-Z0-9_-]/', '_', $test_title);
        $filename   = 'fragengruppierung_' . $safe_title . '_' . date('Ymd_His') . '.csv';

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Pragma: no-cache');
        header('Expires: 0');

        $out = fopen('php://output', 'w');
        fputs($out, "\xEF\xBB\xBF");
        fputcsv($out, array_map([$this, 'csvCell'], $header), ';');

        foreach ($last_passes as $pass) {
            $name  = trim(($pass['firstname'] ?? '') . ' ' . ($pass['lastname'] ?? ''));
            $login = $pass['login'] ?? '';
            // Name inkl. Anmeldename, z.B. "Max Mustermann (mmustermann)"
            $display_name = $name !== '' ? $name . ' (' . $login . ')' : $login;
            $row   = [$display_name, $pass['matriculation'] ?? '', $login];

            foreach ($active_groups as $ag) {
                $res   = $this->getRandomGroupResults($pass['active_id'], $pass['pass'], $ag['pool_ids']);
                $pct   = $res['max'] > 0 ? ($res['reached'] / $res['max']) * 100 : 0;
                $row[] = number_format($res['reached'], 2, ',', '');
                $row[] = number_format($pct,            1, ',', '');
            }

            if ($has_ungrouped) {
                $ug_res = $this->getRandomGroupResults($pass['active_id'], $pass['pass'], $ungrouped_pool_ids);
                $ug_pct = $ug_res['max'] > 0 ? ($ug_res['reached'] / $ug_res['max']) * 100 : 0;
                $row[] = number_format($ug_res['reached'], 2, ',', '');
                $row[] = number_format($ug_pct,            1, ',', '');
            }

            $total = $this->getRandomGroupResults($pass['active_id'], $pass['pass'], array_keys($pools));
            $row[] = number_format($total['reached'], 2, ',', '');

            fputcsv($out, array_map([$this, 'csvCell'], $row), ';');
        }

        fclose($out);
        exit();
    }

    /**
     * Reduziert eine Pass-Liste auf den letzten Durchlauf je Teilnehmer (active_id).
     * Voraussetzung: Passes sind je Teilnehmer aufsteigend nach Pass-Nr sortiert
     * (wie von getSubmittedPasses/getSubmittedPassesRandom geliefert).
     */
    private function getLastPassPerParticipant(array $passes): array
    {
        $last = [];
        foreach ($passes as $pass) {
            $last[$pass['active_id']] = $pass;
        }
        return array_values($last);
    }

    // =========================================================================
    // Hilfsmethoden (nur lesend auf ILIAS-Kerntabellen)
    // =========================================================================

    private function isRandomTest(int $obj_id): bool
    {
        $result = $this->db->queryF(
            "SELECT question_set_type FROM tst_tests WHERE obj_fi = %s",
            ['integer'],
            [$obj_id]
        );
        if ($row = $this->db->fetchAssoc($result)) {
            return $row['question_set_type'] === 'RANDOM_QUEST_SET';
        }
        return false;
    }

    /**
     * Gibt die konfigurierten Fragenpools eines Zufallstests zurück, indiziert nach pool_id (obj_id).
     */
    private function getTestPools(int $obj_id): array
    {
        $result = $this->db->queryF(
            "SELECT test_id FROM tst_tests WHERE obj_fi = %s",
            ['integer'],
            [$obj_id]
        );
        $row = $this->db->fetchAssoc($result);
        if (!$row) {
            return [];
        }
        $test_id = (int) $row['test_id'];

        $result = $this->db->queryF(
            "SELECT p.pool_fi, p.pool_title, p.quest_amount, p.sequence_pos,
                    COALESCE(od.title, p.pool_title) AS actual_title
             FROM tst_rnd_quest_set_qpls p
             LEFT JOIN object_data od ON od.obj_id = p.pool_fi
             WHERE p.test_fi = %s
             ORDER BY p.sequence_pos",
            ['integer'],
            [$test_id]
        );

        $pools = [];
        while ($row = $this->db->fetchAssoc($result)) {
            $pid = (int) $row['pool_fi'];
            $pools[$pid] = [
                'pool_id'      => $pid,
                'title'        => $row['actual_title'] ?? $row['pool_title'] ?? ('Pool #' . $pid),
                'quest_amount' => (int)   $row['quest_amount'],
                'sequence_pos' => (int)   $row['sequence_pos'],
            ];
        }

        return $pools;
    }

    /**
     * Gibt die Pool-IDs zurück, die einer Gruppe zugeordnet sind (Zufallstest).
     */
    private function getGroupPools(int $group_id): array
    {
        $result = $this->db->queryF(
            "SELECT pool_id FROM examgrp_pool_items WHERE group_id = %s",
            ['integer'],
            [$group_id]
        );

        $pool_ids = [];
        while ($row = $this->db->fetchAssoc($result)) {
            $pool_ids[] = (int) $row['pool_id'];
        }

        return $pool_ids;
    }

    /**
     * Berechnet erreichte und maximale Punkte eines Teilnehmers für eine Menge von Pool-IDs.
     * ILIAS kopiert Pool-Fragen intern: tst_test_rnd_qst.question_fi zeigt auf die Kopie.
     * Über qpl_questions.original_id kommt man zur Originalfrage mit dem echten obj_fi (Pool-ID).
     * Gibt ['reached' => float, 'max' => float] zurück.
     */
    private function getRandomGroupResults(int $active_id, int $pass, array $pool_ids): array
    {
        if (empty($pool_ids)) {
            return ['reached' => 0.0, 'max' => 0.0];
        }

        $in_clause = $this->db->in('orig.obj_fi', $pool_ids, false, 'integer');

        $result = $this->db->queryF(
            "SELECT ttrq.question_fi, copy_q.points AS max_points
             FROM tst_test_rnd_qst ttrq
             JOIN qpl_questions copy_q ON copy_q.question_id = ttrq.question_fi
             JOIN qpl_questions orig    ON orig.question_id  = copy_q.original_id
             WHERE ttrq.active_fi = %s AND ttrq.pass = %s AND " . $in_clause,
            ['integer', 'integer'],
            [$active_id, $pass]
        );

        $question_ids = [];
        $max          = 0.0;
        while ($row = $this->db->fetchAssoc($result)) {
            $question_ids[] = (int) $row['question_fi'];
            $max           += (float) $row['max_points'];
        }

        if (empty($question_ids)) {
            return ['reached' => 0.0, 'max' => 0.0];
        }

        $in_q   = $this->db->in('question_fi', $question_ids, false, 'integer');
        $result = $this->db->queryF(
            "SELECT SUM(points) AS reached
             FROM tst_test_result
             WHERE active_fi = %s AND pass = %s AND " . $in_q,
            ['integer', 'integer'],
            [$active_id, $pass]
        );
        $row = $this->db->fetchAssoc($result);

        return [
            'reached' => (float) ($row['reached'] ?? 0.0),
            'max'     => $max,
        ];
    }

    /**
     * Gibt Fragen des Tests zurück, indiziert nach question_fi (= question_id in qpl_questions).
     * Liest nur tst_test_question + qpl_questions.
     */
    private function getTestQuestions(int $obj_id): array
    {
        // obj_id → test_id (interner PK in tst_tests)
        $result = $this->db->queryF(
            "SELECT test_id FROM tst_tests WHERE obj_fi = %s",
            ['integer'],
            [$obj_id]
        );
        $row = $this->db->fetchAssoc($result);
        if (!$row) {
            return [];
        }
        $test_id = (int) $row['test_id'];

        $result = $this->db->queryF(
            "SELECT ttq.question_fi, ttq.sequence, q.title, q.points
             FROM tst_test_question ttq
             JOIN qpl_questions q ON q.question_id = ttq.question_fi
             WHERE ttq.test_fi = %s
             ORDER BY ttq.sequence",
            ['integer'],
            [$test_id]
        );

        $questions = [];
        while ($row = $this->db->fetchAssoc($result)) {
            $questions[(int) $row['question_fi']] = [
                'sequence' => (int)   $row['sequence'],
                'title'    =>         $row['title'],
                'points'   => (float) $row['points'],
            ];
        }

        return $questions;
    }

    private function getGroupsForTest(int $obj_id): array
    {
        // Prüfen ob Threshold-Spalten bereits per DB-Migration vorhanden sind
        $has_threshold = $this->db->tableColumnExists('examgrouping_groups', 'threshold_type');

        $select = $has_threshold
            ? "SELECT id, name, position, threshold_type, threshold_value"
            : "SELECT id, name, position";

        $result = $this->db->queryF(
            "$select FROM examgrouping_groups WHERE test_id = %s ORDER BY position",
            ['integer'],
            [$obj_id]
        );

        $groups = [];
        while ($row = $this->db->fetchAssoc($result)) {
            $groups[] = [
                'id'              => (int)   $row['id'],
                'name'            =>         $row['name'],
                'position'        => (int)   $row['position'],
                'threshold_type'  =>         $row['threshold_type']  ?? 'percent',
                'threshold_value' => (float)($row['threshold_value'] ?? 50.0),
            ];
        }

        return $groups;
    }

    private function getGroupQuestions(int $group_id): array
    {
        $result = $this->db->queryF(
            "SELECT question_id FROM examgrouping_items WHERE group_id = %s",
            ['integer'],
            [$group_id]
        );

        $qids = [];
        while ($row = $this->db->fetchAssoc($result)) {
            $qids[] = (int) $row['question_id'];
        }

        return $qids;
    }

    /**
     * Gibt abgeschlossene Testdurchläufe zurück (submitted = 1).
     * Liest nur tst_active, tst_test_result, usr_data.
     */
    /**
     * Gibt alle abgeschlossenen Passes zurück, alle Durchläufe je Teilnehmer.
     * Rückgabe: gruppiert nach active_id → array of passes (aufsteigend nach pass-Nr).
     * Jeder Eintrag enthält zusätzlich 'submitted_at' (Zeitstempel als string).
     */
    private function getSubmittedPasses(int $obj_id): array
    {
        $result = $this->db->queryF(
            "SELECT test_id FROM tst_tests WHERE obj_fi = %s",
            ['integer'],
            [$obj_id]
        );
        $row = $this->db->fetchAssoc($result);
        if (!$row) {
            return [];
        }
        $test_id = (int) $row['test_id'];

        // Alle Passes mit Ergebnissen laden (nicht nur letzten)
        $result = $this->db->queryF(
            "SELECT ta.active_id, ta.user_fi, ta.submittimestamp,
                    ud.login, ud.firstname, ud.lastname, ud.matriculation,
                    tr.pass
             FROM tst_active ta
             LEFT JOIN usr_data ud ON ta.user_fi = ud.usr_id
             INNER JOIN (
                 SELECT active_fi, pass
                 FROM tst_test_result
                 WHERE points IS NOT NULL
                 GROUP BY active_fi, pass
             ) tr ON tr.active_fi = ta.active_id
             WHERE ta.test_fi = %s AND ta.submitted = 1
             ORDER BY ud.lastname, ud.firstname, ta.active_id, tr.pass ASC",
            ['integer'],
            [$test_id]
        );

        $passes = [];
        while ($row = $this->db->fetchAssoc($result)) {
            $passes[] = [
                'active_id'     => (int) $row['active_id'],
                'user_fi'       => (int) $row['user_fi'],
                'login'         =>       $row['login']           ?? '',
                'firstname'     =>       $row['firstname']       ?? '',
                'lastname'      =>       $row['lastname']        ?? '',
                'matriculation' =>       $row['matriculation']   ?? '',
                'pass'          => (int) $row['pass'],
                'submitted_at'  =>       $row['submittimestamp'] ?? '',
            ];
        }

        return $passes;
    }

    /**
     * Wie getSubmittedPasses, aber für Zufallstests.
     * Nutzt tst_test_rnd_qst statt tst_test_result zur Pass-Erkennung,
     * da tst_test_result bei automatischer Auswertung leer sein kann.
     */
    private function getSubmittedPassesRandom(int $obj_id): array
    {
        $result = $this->db->queryF(
            "SELECT test_id FROM tst_tests WHERE obj_fi = %s",
            ['integer'],
            [$obj_id]
        );
        $row = $this->db->fetchAssoc($result);
        if (!$row) {
            return [];
        }
        $test_id = (int) $row['test_id'];

        $result = $this->db->queryF(
            "SELECT ta.active_id, ta.user_fi, ta.submittimestamp,
                    ud.login, ud.firstname, ud.lastname, ud.matriculation,
                    rq.pass
             FROM tst_active ta
             LEFT JOIN usr_data ud ON ta.user_fi = ud.usr_id
             INNER JOIN (
                 SELECT DISTINCT active_fi, pass
                 FROM tst_test_rnd_qst
             ) rq ON rq.active_fi = ta.active_id
             WHERE ta.test_fi = %s AND ta.submitted = 1
             ORDER BY ud.lastname, ud.firstname, ta.active_id, rq.pass ASC",
            ['integer'],
            [$test_id]
        );

        $passes = [];
        while ($row = $this->db->fetchAssoc($result)) {
            $passes[] = [
                'active_id'     => (int) $row['active_id'],
                'user_fi'       => (int) $row['user_fi'],
                'login'         =>       $row['login']           ?? '',
                'firstname'     =>       $row['firstname']       ?? '',
                'lastname'      =>       $row['lastname']        ?? '',
                'matriculation' =>       $row['matriculation']   ?? '',
                'pass'          => (int) $row['pass'],
                'submitted_at'  =>       $row['submittimestamp'] ?? '',
            ];
        }

        return $passes;
    }

    /**
     * Gibt erreichte Punkte je Frage zurück für einen bestimmten Durchlauf.
     * tst_test_result.points = erreichte Punkte (ILIAS-Konvention).
     * Liest nur tst_test_result – keine Schreibzugriffe.
     */
    private function getQuestionResults(int $active_id, int $pass): array
    {
        $result = $this->db->queryF(
            "SELECT question_fi, points FROM tst_test_result WHERE active_fi = %s AND pass = %s",
            ['integer', 'integer'],
            [$active_id, $pass]
        );

        $results = [];
        while ($row = $this->db->fetchAssoc($result)) {
            $results[(int) $row['question_fi']] = (float) $row['points'];
        }

        return $results;
    }
}
